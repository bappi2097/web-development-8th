﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_portal_V_2
{
    public class ExceptionLog
    {
    }
}